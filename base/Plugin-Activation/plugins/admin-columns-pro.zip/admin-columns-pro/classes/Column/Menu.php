<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @deprecated 4.2.4
 */
class ACP_Column_Menu extends AC_Column {

	// Deprecated. Should be removed at some point.

}
