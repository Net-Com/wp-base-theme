<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ACP_Column_Media_Menu extends ACP_Column_Post_Menu {

}
