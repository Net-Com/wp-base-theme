<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @since 3.0
 */
class AC_Column_Media_Taxonomy extends AC_Column_Post_Taxonomy {
}
