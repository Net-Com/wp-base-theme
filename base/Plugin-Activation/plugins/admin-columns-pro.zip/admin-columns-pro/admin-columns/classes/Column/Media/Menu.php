<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AC_Column_Media_Menu extends AC_Column_Post_Menu {

}
