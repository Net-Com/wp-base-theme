"use strict";// prevents select2 3.5.x from loading
// the layout select2 4.x version get's precedent
window.Select2=1;