<?php 

/*

Plugin Name: NC Templates Render

*/

function render($tpl,$data,$return = false)
{
	$caller = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS,1);
	$dir = dirname($caller[0]['file']).'/tpls/';

	@ob_end_flush();
	ob_start();

	$tpl = $dir.dirname($tpl).'/'.basename($tpl,'.php').'.php';

	if (file_exists($tpl)) {
		if (is_array($data) && !empty($data)) {
			extract($data);
		}
		include $tpl;
		$content = ob_get_clean();

		@ob_end_flush();

		if ($return) {
			return $content;
		}else{
			echo $content;
		}
	}

}