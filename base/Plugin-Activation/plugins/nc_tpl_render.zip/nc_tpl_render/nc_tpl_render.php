<?php 

/*
Plugin Name: NC Templates Render
*/

function render($tplFile, $data = [], $return = false)
{
	$caller		= debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 1);
	$tempoTab	= explode("/", $caller[0]['file']);

	if ( in_array("plugins", $tempoTab) )
	{
		$dir = plugin_dir_path($caller[0]['file']) . 'views/';
	}

	else
    {
		$dir = get_stylesheet_directory() . '/views/';
	}

	@ob_end_flush();
	ob_start();

	$tpl = $dir . dirname($tplFile) . '/' . basename($tplFile,'.php') . '.php';

	if ( !empty($data['tpl_suffix']) )
	{
		$tpl_sfx = $dir . dirname($tplFile) . '/' . basename($tplFile,'.php') . '-' . $data['tpl_suffix'] . '.php';

		if ( file_exists($tpl_sfx) )
			$tpl = $tpl_sfx;
	}

	if ( file_exists($tpl) )
	{
		if ( is_array($data) && !empty($data) )
		{
			extract($data);
		}
		
		if( !empty($_GET['debug']) )
		{
			echo '<!-- *** ' . $tplFile . ' *** -->';
		}

		include $tpl;
		$content = ob_get_clean();

		@ob_end_flush();

		if ( $return )
		{
			return $content;
		}

		else
        {
			echo $content;
		}
	}
}
