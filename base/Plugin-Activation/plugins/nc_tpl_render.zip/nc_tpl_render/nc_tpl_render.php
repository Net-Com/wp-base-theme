<?php 

/*
Plugin Name: NC Templates Render
*/

if ( !empty($_GET['nc_debug']) )
{
	define('NC_RENDER_DEBUG', true);
}

else
{
	define('NC_RENDER_DEBUG', false);
}

function render($tplFile, $data = [], $return = false)
{
	$dirs = [];
	$files = [];
	
	$caller = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 1);
	$tempoTab = explode("/", $caller[0]['file']);
	
	// Appelé depuis un plugin ?
	if ( in_array("plugins", $tempoTab) )
	{
		// Oui
		$dirPlg = plugin_dir_path($caller[0]['file']);
		$plgName = basename($dirPlg);
		
		// Plugin
		// => /views/plugins/nom_du_plugin dans le theme
		// Sinon dossier /views du plugin
		$dirs[] = get_stylesheet_directory() . '/views/plugins/' . $plgName . '/';
		$dirs[] = $dirPlg . 'views/';
	}

	else
	{
		// Non => dossier /src/views/ du theme
		$dirs[] = get_stylesheet_directory() . '/src/views/';
	}
	
	// Extrait le dossier et le nom de la vue sans .php
	$dirFile = dirname($tplFile);
	$nameFile = basename($tplFile, '.php');
	
	// S'il y a un suffixe, on l'utilise en premier
	if ( !empty($data['tpl_suffix']) )
	{
		$files[] = $dirFile . '/' . $nameFile . '-' . $data['tpl_suffix'] . '.php';
	}
	
	// Fichier de vue indiquée
	$files[] = $dirFile . '/' . $nameFile . '.php';

	
	// Cherche le fichier de vue
	$tplView = '';
	
	if ( count($dirs) && count($files) )
	{
		foreach ( $dirs as $dir )
		{
			foreach ( $files as $file )
			{
				$f = $dir . $file;
				
				if ( file_exists($f) )
				{
					$tplView = $f;
					break 2;
				}
			}
		}
	}
	
	// Calcule le retour
	$content = '';
	
	if ( !empty($tplView) )
	{
		if ( is_array($data) && !empty($data) )
		{
			extract($data);
		}
		
		ob_start();
		include $tplView;
		$content = ob_get_contents();
		ob_end_clean();
	}

	if ( NC_RENDER_DEBUG )
	{
		$content = '*** START ' . $tplView . ' ***' . $content . '*** END ' . $tplView . ' ***';
	}
	
	// Renvoi le retour
	if ( $return )
	{
		return $content;
	}

	else
	{
		echo $content;
	}
}


if ( NC_RENDER_DEBUG )
{
	add_action('wp_footer', 'nc_render_debug_files', 99);

	function nc_render_debug_files()
	{
		$files = preg_grep('!/wp-content/themes/!', get_included_files());
		echo '<pre>' . print_r($files, true) . '</pre>';
	}
}
