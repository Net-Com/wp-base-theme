<?php

/**
 * Alter the default password reset title and message
 */
class ProfilePress_Alter_Password_Reset
{

    /** @type array plugin general settings */
    private $db_settings;

    /** @type  object singleton instance */
    static private $instance;

    /** Constructor */
    public function __construct()
    {

        $this->db_settings = get_option('pp_settings_data');

        add_action('retrieve_password_title', array($this, 'title'));

        add_action('retrieve_password_message', array($this, 'message'), 10, 2);
    }


    /**
     * Change the password reset title.
     *
     * @param $title string filter title
     *
     * @return string
     */
    public function title($title)
    {
        $default_title = sprintf(__('[%s] Password Reset'), pp_site_title());
        $title = apply_filters(
            'pp_retrieve_password_title',
            isset($this->db_settings['password_reset_subject']) ? $this->db_settings['password_reset_subject'] : $default_title
        );

        return $title;
    }

    /** @return mixed Raw password reset message from plugin DB settings */
    public function raw_reset_message()
    {
        $default_message = <<<HTML
Someone requested to reset the password for the following account:

Username: {{username}}

If this was a mistake, just ignore this email and nothing will happen.

To reset your password, click the link below:

{{password_reset_link}}


Cheers.
HTML;
        return apply_filters(
            'pp_retrieve_password_message',
            isset($this->db_settings['password_reset_message']) ? $this->db_settings['password_reset_message'] : $default_message
        );
    }


    /**
     * Return the formatted password reset message.
     *
     * @param string $user_login username
     * @param string $key activation key
     * @param string $user_email user email address
     *
     * @return string
     */
    public function formatted_message($user_login, $key, $user_email)
    {
        $raw_message = $this->raw_reset_message();

        $search = apply_filters('pp_password_reset_placeholder_search',
            array(
                '{{username}}',
                '{{password_reset_link}}',
                '{{email}}'
            ),
            $user_login, $key, $user_email
        );

        $replace = apply_filters('pp_password_reset_placeholder_replace',
            array(
                $user_login,
                pp_get_do_password_reset_url($user_login, $key),
                $user_email
            ),
            $user_login, $key, $user_email
        );

        $formatted_message = str_replace($search, $replace, $raw_message);

        return htmlspecialchars_decode($formatted_message);
    }


    /**
     * Callback function for filter
     *
     * @param $message string default reset message supply by password reset form
     * @param $key string activation key supplied by filter
     *
     * @return string formatted message for use by the password reset form
     */
    public function message($message, $key)
    {
        // perform the rituals below to get the username/email entered into the password reset form
        if (strpos($_POST['user_login'], '@')) {
            $user_data = get_user_by('email', trim($_POST['user_login']));
        } else {
            $user_data = get_user_by('login', trim($_POST['user_login']));
        }

        $user_email = $user_data->user_email;

        // Alas! we got the damn user_login
        $user_login = $user_data->user_login;

        $message = $this->formatted_message($user_login, $key, $user_email);

        return $message;

    }


    /**
     * Singleton instance.
     *
     * @return object|ProfilePress_Alter_Password_Reset
     */
    public static function get_instance()
    {
        if (!isset(self::$instance)) {
            self::$instance = new self();
        }

        return self::$instance;

    }
}

ProfilePress_Alter_Password_Reset::get_instance();