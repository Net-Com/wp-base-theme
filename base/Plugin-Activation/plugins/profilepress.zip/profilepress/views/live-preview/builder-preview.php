<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="<?php echo ASSETS_URL . '/css/zocial/zocial.css' ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo ASSETS_URL . '/css/ppcore.css' ?>">
    <script type="text/javascript" src="<?php echo includes_url('js/jquery/jquery.js'); ?>"></script>
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">

    <style type="text/css"></style>
</head>
<body>
Loading...
</body>
</html>