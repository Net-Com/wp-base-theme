<?php
/*
Plugin Name: Pods Edit Custom
Plugin URI: http://net-com.fr/
Description: Description
Version: 1.0
Author: Net.Com
Author URI: http://net-com.fr/
Text Domain: pods-edit-custom
License: GPL v2 or later
*/

/*
    LICENCE PUBLIQUE RIEN À BRANLER
        Version 1, mars 2009

Copyright (C) 2009 Sam Hocevar
 14 rue de Plaisance, 75014 Paris, France

La copie et la distribution de copies exactes de cette licence sont
autorisées, et toute modification est permise à condition de changer
le nom de la licence. 

        CONDITIONS DE COPIE, DISTRIBUTON ET MODIFICATION
              DE LA LICENCE PUBLIQUE RIEN À BRANLER

 0. Faites ce que vous voulez, j’en ai RIEN À BRANLER.
 
  


  This is an add-on for WordPress
  http://wordpress.org/
 
 */
if ( !defined( 'ABSPATH' ) ) exit;
/**
 * Pods_Extend class
 *
 * @class Pods_Extend The class that holds the entire Pods_Extend plugin
 *
 * @since 0.0.1
 */
class Pods_Extend {
	/**
	 * Constructor for the Pods_Extend class
	 *
	 * Sets up all the appropriate hooks and actions
	 * within the plugin.
	 *
	 * @since 0.0.1
	 */
	public function __construct() {
		/**
		 * Plugin Setup
		 */
		register_activation_hook( __FILE__, array( $this, 'activate' ) );
		register_deactivation_hook( __FILE__, array( $this, 'deactivate' ) );
		// Localize our plugin
		/**
		 * Hooks that extend Pods
		 *
		 * NOTE: These are some example hooks that are useful for extending Pods, uncomment as needed.
		 */
		//Example: Add a tab to the pods editor for a CPT Pod called 'jedi
		//add_filter( 'pods_admin_setup_edit_tabs_post_type_test', array( $this, 'pt_tab' ), 11, 3 );
		//Example: Add fields to the Pods editor for all Advanced Content Types
		//add_filter( 'pods_admin_setup_edit_options_advanced', array( $this, 'act_options' ), 11, 2 );
		//Example: Add a submenu item to Pods Admin Menu
		//add_filter( 'pods_admin_menu', array( $this, 'add_menu' ) );
		
		//Complete Example: Add a tab for all post types and some options inside of it.
		//See example callbacks below
		add_filter( 'pods_admin_setup_edit_tabs_post_type', array( $this, 'pt_tab' ), 11, 3 );
		add_filter( 'pods_admin_setup_edit_options_post_type', array( $this, 'pt_options' ), 12, 2 );
		//wp_enqueue_script( 'jquery' );
		add_action( 'admin_footer', array( $this, 'js_admin' ));
	}
	public function js_admin(){
		global $pagenow;

	    if ( !(('post.php' == $pagenow || 'post-new.php' == $pagenow) && get_post_type() != '')) {
	        return;
	    }
	    $podTempo= pods(get_post_type());
	    $pods = pods_api( get_post_type() );
		$tempo = [];
		foreach ($podTempo->fields() as $value) {
			if(pods_v( 'isOk_PEC_'.$value['name'], $pods->pod_data[ 'options' ] )){
				if(pods_v( 'type_PEC_'.$value['name'], $pods->pod_data[ 'options' ] )=="0" && in_array(get_the_ID(), explode(",", pods_v( 'value_PEC_'.$value['name'], $pods->pod_data[ 'options' ] )))){
					?>
						<script>
							jQuery( function ( $ ) {
						        $( '.pods-form-ui-row-name-<?php echo PodsForm::clean( $value[ 'name' ], true );?>').hide();
						    } );
						</script>
					<?php
				}
				if(pods_v( 'type_PEC_'.$value['name'], $pods->pod_data[ 'options' ] )=="1" && !in_array(get_the_ID(), explode(",", pods_v( 'value_PEC_'.$value['name'], $pods->pod_data[ 'options' ] )))){
					?>
						<script>
							jQuery( function ( $ ) {
						        $( '.pods-form-ui-row-name-<?php echo PodsForm::clean( $value[ 'name' ], true );?>').hide();
						    } );
						</script>
					<?php
				}
			}
		}
		
	}

	/**
	 * Initializes the Pods_Extend() class
	 *
	 * Checks for an existing Pods_Extend() instance
	 * and if it doesn't find one, creates it.
	 *
	 * @since 0.0.1
	 */
	public static function init() {
		static $instance = false;
		if ( ! $instance ) {
			$instance = new Pods_Extend();
		}
		return $instance;
		
	}
	/**
	 * Placeholder for activation function
	 *
	 * @since 0.0.1
	 */
	public function activate() {
	}
	/**
	 * Placeholder for deactivation function
	 *
	 * @since 0.0.1
	 */
	public function deactivate() {
	}

	/**
	 * Adds an admin tab to Pods editor for all post types
	 *
	 * @param array $tabs The admin tabs
	 * @param object $pod Current Pods Object
	 * @param $addtl_args
	 *
	 * @return array
	 *
	 * @since 0.0.1
	 */
	function pt_tab( $tabs, $pod, $addtl_args ) {
		$tabs[ 'pods-edit-custom' ] = __( 'Pods Edit Custom', 'pods-edit-custom' );
		
		return $tabs;
		
	}
	/**
	 * Adds options to Pods editor for post types
	 *
	 * @param array $options All the options
	 * @param object $pod Current Pods object.
	 *
	 * @return array
	 *
	 * @since 0.0.1
	 */
	function pt_options( $options, $pod  ) {
		$podTempo= pods($pod['name']);
		$tempo = [];
		foreach ($podTempo->fields() as $value) {
			$tempo ['isOk_PEC_'.$value['name']] = [
				'label' => __( $value['name'].' : gérer la modification backoffice', 'pods-edit-custom' ),
				'help' => __( 'Activer / Désactiver la modification de '.$value['name'].' en backoffice', 'pods-edit-custom' ),
				'type' => 'boolean',
				'default' => false,
				'dependency' => true,
				'boolean_yes_label' => '',
                ];
			$tempo ['type_PEC_'.$value['name']] = [
				'label' => __( 'Afficher le champs pour', 'pods-edit-custom' ),
				'help' => __( 'Afficher '.$value['name'].' en backoffice pour', 'pods-edit-custom' ),
				'type' => 'pick',
                'data' => array(
                	'Tous sauf',
                	'Aucun sauf'
                	),
                'depends-on' => array( 'isOk_PEC_'.$value['name'] => true )
                ];
            $tempo ['value_PEC_'.$value['name']] = [
				'label' => __( 'Liste des ID des pages / posts', 'pods-edit-custom' ),
				'help' => __( 'Liste des ID des pages / posts', 'pods-edit-custom' ),
				'type' => 'text',
                'data' => array(
                	'Tous sauf',
                	'Aucun sauf'
                	),
                'depends-on' => array( 'isOk_PEC_'.$value['name'] => true )
                ];
		}
		$options[ 'pods-edit-custom' ] = $tempo;
		return $options;
		
	}

} // Pods_Extend
/**
 * Initialize class, if Pods is active.
 *
 * @since 0.0.1
 */
add_action( 'plugins_loaded', 'pods_extend_safe_activate');
function pods_extend_safe_activate() {
	if ( defined( 'PODS_VERSION' ) ) {
		$GLOBALS[ 'Pods_Extend' ] = Pods_Extend::init();
	}
}
/**
 * Throw admin nag if Pods isn't activated.
 *
 * Will only show on the plugins page.
 *
 * @since 0.0.1
 */
add_action( 'admin_notices', 'pods_extend_admin_notice_pods_not_active' );
function pods_extend_admin_notice_pods_not_active() {
	if ( ! defined( 'PODS_VERSION' ) ) {
		//use the global pagenow so we can tell if we are on plugins admin page
		global $pagenow;
		if ( $pagenow == 'plugins.php' ) {
			?>
			<div class="updated">
				<p><?php _e( 'You have activated Pods Extend, but not the core Pods plugin.', 'pods_extend' ); ?></p>
			</div>
		<?php
		} //endif on the right page
	} //endif Pods is not active
}
/**
 * Throw admin nag if Pods minimum version is not met
 *
 * Will only show on the Pods admin page
 *
 * @since 0.0.1
 */
add_action( 'admin_notices', 'pods_extend_admin_notice_pods_min_version_fail' );
function pods_extend_admin_notice_pods_min_version_fail() {
	if ( defined( 'PODS_VERSION' ) ) {
		//set minimum supported version of Pods.
		$minimum_version = '2.3.18';
		//check if Pods version is greater than or equal to minimum supported version for this plugin
		if ( version_compare(  $minimum_version, PODS_VERSION ) >= 0) {
			//create $page variable to check if we are on pods admin page
			$page = pods_v('page','get', false, true );
			//check if we are on Pods Admin page
			if ( $page === 'pods' ) {
				?>
				<div class="updated">
					<p><?php _e( 'Pods Extend, requires Pods version '.$minimum_version.' or later. Current version of Pods is '.PODS_VERSION, 'pods_extend' ); ?></p>
				</div>
			<?php
			} //endif on the right page
		} //endif version compare
	} //endif Pods is not active
}