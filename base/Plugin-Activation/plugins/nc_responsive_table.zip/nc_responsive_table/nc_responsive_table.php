<?php
/*
Plugin Name: NC Responsive table
Plugin URI: http://net-com.fr/
Description: Net.Com Responsive table - Rend les tableaux responsive. Nécessite le plugin XXX + config
Version: 1.0
Author: Net.Com
Author URI: http://net-com.fr/
License: GPL v2 or later
*/


/*
**	Détection des dépendances
*/
add_action( 'admin_init', 'nc_responsive_table_detect' );

function nc_responsive_table_detect()
{
    if ( is_admin() && current_user_can( 'activate_plugins' ) &&  !is_plugin_active( 'advanced-tinymce-configuration/adv-mce-config.php' ) )
	{
        add_action( 'admin_notices', 'nc_responsive_table_notice' );

        deactivate_plugins( plugin_basename( __FILE__ ) ); 

        if ( isset( $_GET['activate'] ) )
		{
            unset( $_GET['activate'] );
        }
    }
}

function nc_responsive_table_notice()
{
    ?>
	<div class="error">
		<p>NC Responsive table : Merci d'installer et de configurer le plugin advanced-tinymce-configuration (<a href="/wp-admin/plugin-install.php?s=advanced+tinymce+configuration&tab=search&type=term" target="_blank">ici</a>).</p>
		<p>Configuration : Ajouter l'option <b>table_class_list</b> avec pour valeur 
<pre>
[
	{title: 'None', value: ''},
	{title: 'Tableau responsive', value: 'nc-table-responsive'},
]</pre>
		</p>
	</div>
	<?php
}

/*
**	Injection CSS + JS
*/
add_action( 'wp_enqueue_scripts', 'nc_responsive_table_scripts' );
function nc_responsive_table_scripts()
{
	wp_enqueue_script( 'nc_responsive_table_stacktable',  plugin_dir_url(__FILE__) . 'assets/stacktable.js', array(), 1, true );
	wp_enqueue_style( 'nc_responsive_table', plugin_dir_url(__FILE__) . 'assets/nc_responsive_table.css');
	wp_enqueue_script( 'nc_responsive_table',  plugin_dir_url(__FILE__) . 'assets/nc_responsive_table.js', array(), 1, true );
}


