jQuery(document).ready(function($) {
	if($('.nc-table-responsive').length)
	{
		$('.nc-table-responsive').cardtable();
	}
});

