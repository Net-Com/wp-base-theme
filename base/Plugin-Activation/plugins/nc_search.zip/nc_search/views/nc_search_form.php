<div class="">
	<?php get_search_form(); ?>
</div>