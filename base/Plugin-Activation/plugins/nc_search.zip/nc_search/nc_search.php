<?php
/*
Plugin Name: NC Search
Plugin URI: http://net-com.fr/
Description: Net.Com Search - Configure la page de recherche. Installez le plugin Genesis Translation
Version: 1.0
Author: Net.Com
Author URI: http://net-com.fr/
License: GPL v2 or later
*/


/*****************************************************************
**		Force "No result" si la recherche est vide
*/
add_filter( 'posts_search', 'nc_search_query', 10, 2 );

function nc_search_query($search, \WP_Query $q)
{
    if( ! is_admin() && empty( $search ) && $q->is_search() && $q->is_main_query() )
        $search .=" AND 0=1 ";

    return $search;
}


/*****************************************************************
**		Mise en place des actions si on est sur la page de recherche
*/
add_action('wp', 'nc_search_actions', 10);

function nc_search_actions()
{
	if(is_search())
	{
		add_action('genesis_before_loop', 'nc_search_excerpt' );
		add_action('genesis_before_loop', 'nc_search_add_form', 12);
		remove_action('genesis_entry_header', 'genesis_post_info', 12);
	}
}


/*****************************************************************
**		Utilise les r�sum�s sur la page de recherche
*/
function nc_search_excerpt()
{
	if ( is_search() )
	{
		add_filter( 'genesis_pre_get_option_content_archive', '__nc_search_return_excerpt' );
	}
}

function __nc_search_return_excerpt() { return 'excerpts'; }


/*****************************************************************
**		Ajoute le formulaire au d�but de la page de recherche
*/
function nc_search_add_form()
{
	if(is_search())
		render('nc_search_form', []);
}

/*****************************************************************
**		Texte du bouton Rechercher
**		Formulaire complet surcharg� par le th�me enfant
*/
/*
add_filter( 'genesis_search_button_text', 'nc_search_button_text' );
function nc_search_button_text( $text )
{
	return esc_attr( 'Go' );
}

*/

/*****************************************************************
**		Texte du placeholder
*/

add_filter( 'genesis_search_text', 'nc_search_placeholder' );
function nc_search_placeholder( $text )
{
	return esc_attr( 'Votre recherche...' );
}



/*****************************************************************
**		Filtres
**
**		genesis_search_title_output :	Titre de la page de recherche
**										D�faut : <div class="archive-description"><h1 class="archive-title">R�sultats de recherche pour : ***</h1></div>
**										Appel� dans l'action genesis_before_loop => genesis_do_search_title
**
**		genesis_search_form :			Surcharge le formulaire de recherche. Code plac� dans theme_enfant/base/lib/search-form.php
**
**/


















