<h1>Pages non supprimables</h1>

<?php
$nbp = count($pages);
if($nbp)
{
	?>
	<form method="post">
		<button type="submit" class="button button-primary right">Enregistrer</button>
		<h3><?php echo $nbp; ?> page<?php echo $nbp ? 's' : ''; ?></h3>
		<table class="wp-list-table widefat fixed striped">
			<thead>
				<tr>
					<th>ID</th>
					<th>Titre</th>
					<th>Protégée</th>
				</tr>
			</thead>
			<tbody>
				<?php
				foreach($pages as $p)
				{
					?>
					<tr>
						<td><?php echo $p->ID; ?></td>
						<td><label for="cb_<?php echo $p->ID; ?>"><?php echo $p->post_title; ?></label></td>
						<td><input type="checkbox" name="protected[<?php echo $p->Id; ?>]" id="cb_<?php echo $p->ID; ?>" value="<?php echo $p->ID; ?>" <?php echo isset($protected[$p->ID]) ? 'checked' : ''; ?>/></td>
					</tr>
					<?php
				}
				?>
			</tbody>
		</table>
		
		<input type="hidden" name="nc_disable_delete_page" value="true">
		<button type="submit" class="button button-primary right">Enregistrer</button>
	</form>
	<?php
}
else
{
	?>
	<div class="alert alert-danger">Pas de pages</div>
	<?php
}


