<?php
add_action('admin_menu','nc_disable_delete_page_admin_menu');

function nc_disable_delete_page_admin_menu()
{
    add_options_page(
        'Pages non supprimables',
        'Pages non supprimables',
        'manage_options',
        'nc_disable_delete_page.php',
        'nc_disable_delete_page',
        'dashicons-admin-generic',
        7
    );
}


function nc_disable_delete_page()
{
	if(!empty($_POST['nc_disable_delete_page']))
	{
		$protected = array();
		
		if(isset($_POST['protected']))
			$protected = $_POST['protected'];
		
		if(!empty($protected))
			$protected = serialize(array_flip($_POST['protected']));
		update_option( 'nc_disable_delete_protected', $protected );
    }

	
	$pages = get_pages(array(
		'post_status' => 'publish,private,draft,trash',
		'sort_order' => 'asc',
		'sort_column' => 'post_title',
		'hierarchical'	=> 0,
	));
	
	dsm($pages);
	
	$protected = nc_disable_delete_get_protected();
	
    render('nc_disable_delete_page', array('pages' => $pages, 'protected' => $protected) );
}

function nc_disable_delete_get_protected()
{
	$protected = get_option('nc_disable_delete_protected', array());
	dsm($protected);
	if(!empty($protected))
		$protected = (array)unserialize($protected);
	return $protected;
}




function nc_disable_delete_restict_action($post_ID)
{
    $protected = nc_disable_delete_get_protected();
	
    if(isset($protected[$post_ID]))
	{
        echo "You are not authorized to delete this page.";
        exit;
    }
}

add_action('wp_trash_post',			'nc_disable_delete_restict_action', 10, 1);
add_action('before_delete_post',	'nc_disable_delete_restict_action', 10, 1);
add_action('trash_post',			'nc_disable_delete_restict_action', 10, 1);
add_action('delete_post',			'nc_disable_delete_restict_action', 10, 1);





