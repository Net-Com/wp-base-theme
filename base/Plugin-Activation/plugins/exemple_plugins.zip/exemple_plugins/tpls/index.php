<form method="post">
<h1>Exemple page admin</h1>
<label for="title">Titre</label>
<input type="text" id="title" name="gabarit_mail_titre_expirationassurance" value="<?=get_option('gabarit_mail_titre_expirationassurance')?>"><br><br>
<label>Contenu</label>
<div style="width:500px">
	<?php wp_editor( $content, 'gabarit_mail_expirationassurance')?>
</div>
<?php submit_button('Sauvegarder', 'primary')?>
</form>

<h2>Facebook</h2>
<?=get_option('social_facebook')?>