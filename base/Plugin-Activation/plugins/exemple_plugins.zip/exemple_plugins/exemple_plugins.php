<?php 

/*

Plugin Name: Exemple plugins

*/

add_action( 'admin_menu', 'admin_page_alerte' );
function admin_page_alerte() {
    add_menu_page( 'Gestion diverses', 'Gestion', 'manage_options', 'NC-Menu', 'GabaritMail', 'dashicons-tickets', 6  );
}
function GabaritMail() {
    if(isset($_POST['gabarit_mail_titre_expirationassurance'])){
        update_option('gabarit_mail_titre_expirationassurance', stripslashes($_POST['gabarit_mail_titre_expirationassurance']));
    }
    if(isset($_POST['gabarit_mail_expirationassurance'])){
        update_option('gabarit_mail_expirationassurance', stripslashes($_POST['gabarit_mail_expirationassurance']));
    }
    render('index',['content'=>get_option('gabarit_mail_expirationassurance')]);
}