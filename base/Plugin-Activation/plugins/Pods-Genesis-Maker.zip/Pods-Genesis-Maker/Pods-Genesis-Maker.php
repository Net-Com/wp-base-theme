<?php
/*
Plugin Name: Pods Genesis Maker
Plugin URI: http://net-com.fr/
Description: Description
Version: 1.0
Author: Net.Com
Author URI: http://net-com.fr/
Text Domain: pods-genesis-maker
License: GPL v2 or later
*/

/**
 * Copyright (c) 2017 bmilot@net-com.fr (email: bmilot@net-com.fr). All rights reserved.
 *
 * Released under the GPL license
 * http://www.opensource.org/licenses/gpl-license.php
 *
 * This is an add-on for WordPress
 * http://wordpress.org/
 *
 */
// don't call the file directly
if ( !defined( 'ABSPATH' ) ) exit;

/**
 * Define constants
 *
 * @since 0.0.2
 */
define( 'PODS_GENESIS_MAKER_SLUG', plugin_basename( __FILE__ ) );
define( 'PODS_GENESIS_MAKER_URL', plugin_dir_url( __FILE__ ) );
define( 'PODS_GENESIS_MAKER_DIR', plugin_dir_path( __FILE__ ) );

/**
 * Pods_Genesis_Maker class
 *
 * @class Pods_Genesis_Maker The class that holds the entire Pods_Genesis_Maker plugin
 *
 * @since 0.0.1
 */
class Pods_Permalien_Ariane {
	private $pageEnCours;
	/**
	 * Constructor for the Pods_Genesis_Maker class
	 *
	 * Sets up all the appropriate hooks and actions
	 * within the plugin.
	 *
	 * @since 0.0.1
	 */

	public function init(){

		global $PGM_contexte;
		//fil d'ariane
		add_filter('query_vars', array( $this, 'add_variables_url'));
		//permaliens
		add_filter( 'post_type_link' , array( $this, 'ecriture_permaliens'), 9, 2 );
		add_filter( 'post_link' , array( $this, 'ecriture_permaliens'), 9, 2 );
		add_filter( 'page_link' , array( $this, 'ecriture_permaliens_page'), 9, 2 );
		//url
		add_action( 'wp_loaded' , array( $this, 'regles_ecritures_url' ), 10, 0);
	}
	public function add_variables_url($public_query_vars) {
	    $public_query_vars[] = 'ariane';
	    return $public_query_vars;
	}
	public function ecriture_permaliens_page( $permalink, $id){
		return $this->ecriture_permaliens($permalink,get_post($id));
	}
	public function ecriture_permaliens( $permalink, $post){
		global $wpdb,$PGM_contexte;
		$dpgmc = $PGM_contexte;
		$this->pageEnCours 	= get_the_ID();
		if($PGM_contexte!=""){
			$cumulContexte  = $PGM_contexte;
			$Tabariane 		= explode(";", $PGM_contexte);
			if($PGM_contexte=="0"){
				$cumulContexte = "";
				$Tabariane = array();
			}
		}else{
			$cumulContexte = get_query_var('ariane');
			if($cumulContexte!=""){
				$Tabariane 		= explode(";", $cumulContexte);
				$cumulContexte .= ";";
			}
			$cumulContexte 	.= $this->pageEnCours;
			$Tabariane[] 	=  $this->pageEnCours;
		}

		for ($i=sizeof($Tabariane); $i > -1; $i--) { 	
			$tempopost = strrpos($cumulContexte, ";");
			if($tempopost){
				$newID = substr($cumulContexte, $tempopost+1);
				$cumulContexte=substr($cumulContexte, 0,$tempopost);
			}else{
				
				$newID = $cumulContexte;
				$cumulContexte="Defaut";
			}
			$sql="
				SELECT action.*
				FROM ".$wpdb->prefix."pgm_action_post action
				WHERE 
					action.contexte='".$cumulContexte."'
					AND action.post_id = '".$newID."'
					AND action.param_pods_name='".$post->post_type."'
					AND action.param_iscptslug='1'
				";
			$hooks = $wpdb->get_results($sql);
			if( !empty($hooks)) {
				if($cumulContexte == "Defaut"){
					$cumulContexte = "0";
				}
				$PGM_contexte=$cumulContexte;
		       	$permalink = get_permalink($hooks[0]->post_id);
		       	$PGM_contexte=$dpgmc;
	    		foreach ( get_post_ancestors($post) as $ancestor ) {
		        	$permalink .= get_post($ancestor)->post_name.'/';
				}
		        $permalink .= $post->post_name.'/';
		        return $permalink ;
		    }
		}
		return $permalink;
	}
	public function regles_ecritures_url(){
		global $wpdb;
		$sql="
					SELECT action.*
					FROM ".$wpdb->prefix."pgm_action_post action
					WHERE 
						action.contexte='Defaut' 
						AND action.post_id !='0'
						AND action.param_iscptslug='1'
					ORDER BY
						ID DESC";
		$posts = $wpdb->get_results($sql);
		foreach($posts as $post) {
			$this->generer_permaliens($post,'');
		}
	}
	public function generer_permaliens($post,$ariane){
		global $wpdb;
		$url = "";
		if($ariane==''){
			if($post->param_secureiscptslug == 1){
				if($post->post_type == "page" || $post->post_type=='post'){
					$url .= str_replace(home_url()."/", '', get_permalink($post->post_id).$post->param_pods_name."/");
				}else{
					$post_type_data = get_post_type_object( $post->post_type );
    				$post_type_slug = $post_type_data->rewrite['slug'];
					$url .= str_replace(home_url()."/", '', get_permalink($post->post_id).$post_type_slug."/");
				}
			}else{
				if($post->post_type == "page" || $post->post_type=='post'){
					$url .= str_replace(home_url().'/','', get_permalink($post->post_id));
				}else{
					$url .= str_replace(home_url()."/", '', get_permalink($post->post_id));
				}
			}
			$ariane .= $post->post_id;
		}else{
			$cumulAriane ="";
			$tabAriane = explode(";", $ariane);
			$next = $tabAriane[0];
			$tabnext_type_namecpt = $this->get_type_namecpt($next,"Defaut");
			$post_type_next = $tabnext_type_namecpt[0];
			$pod_namecpt_next = $tabnext_type_namecpt[1];
			$post_type_next = $tabnext_type_namecpt[2];
			$secrure_slug_next = $tabnext_type_namecpt[3];
			if($secrure_slug_next == 1){
				if($post_type_next == "page" || $post_type_next=='post'){
					$url .= str_replace(home_url()."/", '', get_permalink($next).$pod_namecpt_next."/");
				}else{
					$url .= str_replace(home_url()."/".$post_type_next."/", '', get_permalink($next).$pod_namecpt_next."/");
				}
			}else{
				if($post_type_next == "page" || $post_type_next=='post'){
					$url .= str_replace(home_url()."/", '', get_permalink($next));
				}else{
					$post_type_data = get_post_type_object( $post_type_next );
    				$post_type_slug = $post_type_data->rewrite['slug'];
					$url .= str_replace(home_url()."/", '', get_permalink($next));
				}
			}
			
			$i=0;
			foreach ($tabAriane as $value) {

				if($value!=""){
					$cumulAriane .= $value;

					if(isset($tabAriane[$i+1])){
						$next = $tabAriane[$i+1];
						$tabnext_type_namecpt = $this->get_type_namecpt($next,$cumulAriane);
						$post_type_next = $tabnext_type_namecpt[0];
						$pod_namecpt_next = $tabnext_type_namecpt[1];
						$post_type_next = $tabnext_type_namecpt[2];
						$secrure_slug_next = $tabnext_type_namecpt[3];
					}else{
						$next = $post->post_id;
						$post_type_next = $post->post_type;
						$pod_name_next = $post->param_pods_name;
						$post_type_next = $post->post_type;
						$secrure_slug_next = $post->param_secureiscptslug;
					}
					if($secrure_slug_next == 1){
						if($post_type_next == "page" || $post_type_next=='post'){
							$url .= str_replace(home_url()."/", '', get_permalink($next).$pod_namecpt_next."/");
						}else{
							$url .= str_replace(home_url()."/".$post_type_next."/", '', get_permalink($next).$pod_namecpt_next."/");
						}
					}else{
						if($post_type_next == "page" || $post_type_next=='post'){
							$url .= str_replace(home_url()."/", '', get_permalink($next));
						}else{
							$post_type_data = get_post_type_object( $post_type_next );
    						$post_type_slug = $post_type_data->rewrite['slug'];
							$url .= str_replace(home_url()."/".$post_type_slug."/", '', get_permalink($next));
						}
					}
					$cumulAriane .= ";";
					$i++;
				}
			}
			$ariane .= ";".$post->post_id;
		}
		if($post->param_pods_name != ""){
			$sql="
					SELECT action.*
					FROM ".$wpdb->prefix."pgm_action_post action
					WHERE 
						action.contexte='".$ariane."' 
						AND action.post_id !='0'
						AND action.param_iscptslug='1'
					";
			$postsAutres = $wpdb->get_results($sql);
			foreach($postsAutres as $postsAutre) {
				$this->generer_permaliens($postsAutre,$ariane);
			}
			if(substr($url,0,-1)!=""){
				add_rewrite_rule('^'.substr($url,0,-1).'.*/([^/]+)/?','index.php?post_type='.$post->param_pods_name.'&name=$matches[1]&ariane='.$ariane,'top');
				//echo "==>".substr($url,0,-1)."===>".$post->param_pods_name."<BR>";
			}
			
		}
	}
	function get_type_namecpt($id,$contexte){
		global $wpdb;
		$sql="
					SELECT action.post_type, action.param_pods_name, action.post_type,action.param_secureiscptslug
					FROM ".$wpdb->prefix."pgm_action_post action
					WHERE 
						action.post_id='".$id."'
						AND action.contexte = '".$contexte."'
					";
		$row = $wpdb->get_results($sql);
		return array($row[0]->post_type,$row[0]->param_pods_name,$row[0]->post_type,$row[0]->param_secureiscptslug);
	}
}
/**
 * Pods_Genesis_Maker class
 *
 * @class Pods_Genesis_Maker The class that holds the entire Pods_Genesis_Maker plugin
 *
 * @since 0.0.1
 */

class Pods_Genesis_Maker {
	private $pageEnCours;
	private $TabType = array(
		'add_action' 		=> 'add_action',
		'add_filter' 		=> 'add_filter',
		'remove_action' 	=> 'remove_action',
		'remove_filter' 	=> 'remove_filter');
	private $TabListePods 	= array();
	private $pgm_action_post;	
	private $excludeListeHookContexte = array(
		 'Contexte' => "'ajouter_contexte'"
		);
	/**
	 * Constructor for the Pods_Genesis_Maker class
	 *
	 * Sets up all the appropriate hooks and actions
	 * within the plugin.
	 *
	 * @since 0.0.1
	 */
	public function __construct() {
		global $wpdb;
		/**
		 * Plugin Setup
		 */
		
		// Localize our plugin
		add_action( 'init', array( $this, 'localization_setup' ) );
		$contextes = new Pods_Permalien_Ariane();
		$contextes->init();
		if(is_admin()){
			$this->configuration();
			// Loads admin scripts and styles
			add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue_scripts' ));
			//Hooks that extend Pods
			add_filter( 'pods_admin_menu', array( $this, 'add_menu' ) );
		}else{
			// Loads frontend scripts and styles
			add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
			add_action( 'wp', array( $this, 'is_page_pods' ),1 );
		}
	}
	public function configuration(){
		$pods_type 		= (new WP_Query(array('post_type' => '_pods_pod', 'posts_per_page' => -1)))->posts;
		foreach($pods_type as $pod_type) {
			$this->TabListePods[$pod_type->post_name] = $pod_type->post_title;
		}
	}
	/**
	 * Initializes the Pods_Genesis_Maker() class
	 *
	 * Checks for an existing Pods_Genesis_Maker() instance
	 * and if it doesn't find one, creates it.
	 *
	 * @since 0.0.1
	 */
	public static function init() {
		static $instance = false;

		if ( ! $instance ) {
			$instance = new Pods_Genesis_Maker();
		}

		return $instance;
		
	}

	/**
	 * Placeholder for activation function
	 *
	 * @since 0.0.1
	 */
	public function activate() {
		global $wpdb;
	  	$version = get_option( 'Pod_Genesis_Maker_version', '1.0' );
		$charset_collate = $wpdb->get_charset_collate();
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		
		$sql="DROP TABLE IF EXISTS ".$wpdb->prefix."pgm_action_post";
		$wpdb->query( $sql );
		$sql="DROP TABLE IF EXISTS ".$wpdb->prefix."pgm_ne_pas_executer";
		$wpdb->query( $sql );
		$sql=
			"
			CREATE TABLE IF NOT EXISTS `".$wpdb->prefix."pgm_ne_pas_executer` (
				`pgm_action_post_id` bigint(20) NOT NULL,
				`post_id` bigint(20) NOT NULL,
				`contexte` varchar(255) NOT NULL,
				PRIMARY KEY (`pgm_action_post_id`,`post_id`,`contexte`)
			);
			";
		dbDelta( $sql );
		$sql=
			"
			CREATE TABLE IF NOT EXISTS `".$wpdb->prefix."pgm_action_post` (
				`ID` bigint(20) NOT NULL AUTO_INCREMENT,
				`post_type` varchar(255) NOT NULL,
				`post_id` bigint(20) NOT NULL,
				`contexte` varchar(255) NOT NULL,
				`type` varchar(255) NOT NULL,
				`hook` varchar(255) NOT NULL,
				`action` varchar(255) NOT NULL,
				`priorite` INT(11),
				`parametres` int(11),
				`param_iscptslug` INT(1),
				`param_secureiscptslug` INT(1),
				`param_pods_name` varchar(255),
				PRIMARY KEY (`ID`)
			);
		";
		dbDelta( $sql );	
	}

	/**
	 * Placeholder for deactivation function
	 *
	 * @since 0.0.1
	 */
	public function deactivate() {

	}

	/**
	 * Initialize plugin for localization
	 *
	 * @since 0.0.1
	 */
	public function localization_setup() {
		
		load_plugin_textdomain( 'pods-genesis-maker', false, trailingslashit( PODS_GENESIS_MAKER_URL ) . '/languages/' );
		
	}

	/**
	 * Enqueue front-end scripts
	 *
	 * Allows plugin assets to be loaded.
	 *
	 * @since 0.0.1
	 */
	public function enqueue_scripts() {

		/**
		 * All styles goes here
		 */
		wp_enqueue_style( 'pods-genesis-maker-styles', trailingslashit( PODS_GENESIS_MAKER_URL ) . 'css/front-end.css' );

		/**
		 * All scripts goes here
		 */
		wp_enqueue_script( 'pods-genesis-maker-scripts', trailingslashit( PODS_GENESIS_MAKER_URL ) . 'js/front-end.js', array( ), false, true );
		
	}

	/**
	 * Enqueue admin scripts
	 *
	 * Allows plugin assets to be loaded.
	 *
	 * @since 0.0.1
	 */
	public function admin_enqueue_scripts() {

		if(!empty($_GET['page']) && ($_GET['page'] == 'pods-genesis-maker'))
		{
		/**
		 * All admin styles goes here
		 */
		wp_enqueue_style( 'bootstrap-css', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css', false, NULL, 'all' );	
		wp_enqueue_style( 'pods-genesis-maker-admin-styles', plugins_url( 'css/admin.css', __FILE__ ) );
		/**
		 * All admin scripts goes here
		 */
		wp_enqueue_script( 'pods-genesis-maker-admin-scripts', plugins_url( 'js/admin.js', __FILE__ ), array( ), false, true );
		wp_enqueue_script( 'jquery-ui-tabs' );
		wp_enqueue_script( 'bootstrap-js-2', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js', array('jquery'), NULL, true );
		}
    
		
	}
	

	public function is_page_pods(){
		global $wpdb;
		if ( is_page() || is_single() ) {
			$this->pageEnCours = get_the_ID();
			$post_type = get_post_type($this->pageEnCours);

			$sql="
				SELECT action.*
				FROM ".$wpdb->prefix."pgm_action_post action 
				LEFT JOIN `".$wpdb->prefix."pgm_ne_pas_executer` npe 
					ON npe.pgm_action_post_id = action.ID 
					AND npe.post_id='".$this->pageEnCours."' 
					AND npe.contexte='".$this->getContexte()."' 
				LEFT JOIN `".$wpdb->prefix."pgm_ne_pas_executer` npe2
					ON npe2.pgm_action_post_id = action.ID 
					AND npe2.post_id='0'
					AND npe2.contexte='".$this->getContexte()."' 
				LEFT JOIN `".$wpdb->prefix."pgm_ne_pas_executer` npe3 
					ON npe3.pgm_action_post_id = action.ID 
					AND npe3.post_id='".$this->pageEnCours."' 
					AND npe3.contexte='Tous' 
				WHERE 
					action.contexte='Tous' 
					AND action.post_id='0' 
					AND action.post_type='".$post_type."' 
					AND npe.pgm_action_post_id IS NULL
					AND npe2.pgm_action_post_id IS NULL
					AND npe3.pgm_action_post_id IS NULL
				ORDER BY 
					action.hook ASC,action.priorite ASC";

			$hooks = $wpdb->get_results($sql);
			$this->executeHook($hooks);
			
			//action de post contexte en cours
			$sql="
				SELECT action.*
				FROM ".$wpdb->prefix."pgm_action_post action 
				LEFT JOIN `".$wpdb->prefix."pgm_ne_pas_executer` npe 
					ON npe.pgm_action_post_id = action.ID 
					AND npe.post_id='".$this->pageEnCours."' 
					AND npe.contexte='".$this->getContexte()."'
				WHERE 
					action.contexte='".$this->getContexte()."' 
					AND action.post_id='0' 
					AND action.post_type='".$post_type."' 
					AND npe.pgm_action_post_id IS NULL
				ORDER BY 
					action.hook ASC,action.priorite ASC";
			$hooks = $wpdb->get_results($sql);
			$this->executeHook($hooks);

			//actions de page contexte "Tous"
			$sql="
				SELECT action.*
				FROM ".$wpdb->prefix."pgm_action_post action 
				LEFT JOIN `".$wpdb->prefix."pgm_ne_pas_executer` npe 
					ON npe.pgm_action_post_id = action.ID 
					AND npe.post_id='".$this->pageEnCours."' 
					AND npe.contexte='".$this->getContexte()."'
				WHERE 
					action.contexte='Tous' 
					AND action.post_id='".$this->pageEnCours."' 
					AND action.post_type='".$post_type."' 
					AND npe.pgm_action_post_id IS NULL
				ORDER BY 
					action.hook ASC,action.priorite ASC";
			$hooks = $wpdb->get_results($sql);
			$this->executeHook($hooks);

			//action de page contexte en cours
			$sql="
				SELECT action.*
				FROM ".$wpdb->prefix."pgm_action_post action
				WHERE 
					action.contexte='".$this->getContexte()."' 
					AND action.post_id='".$this->pageEnCours."'
					AND action.post_type='".$post_type."' 
				ORDER BY 
					action.hook ASC,action.priorite ASC";
			$hooks = $wpdb->get_results($sql);
			$this->executeHook($hooks);
		}
	}

	function executeHook($hooks){
		foreach ($hooks as $hook) {
			if(function_exists ($hook->action)){
				$this->constructHook($hook->type,$hook->hook,$hook->action,$hook->priorite,$hook->parametres);
			}
		}
	}
	function constructHook($type,$hook,$action,$priorite,$parametres){
		if(substr($type, 0,6)=='remove'){
			if($priorite!=""){
				$type($hook,$action,$priorite);
			}else{
				$type($hook,$action);
			}
		}elseif(substr($type, 0,3)=='add'){
			if($parametres!=""){
				if($priorite!=""){
					$type($hook,$action,$priorite,$parametres);
				}else{
					$type($hook,$action,10,$parametres);
				}
			}else{
				if($priorite!=""){
					$type($hook,$action,$priorite);
				}else{
					$type($hook,$action);
				}
			}
		}

	}
	function getContexte(){
		$contexte = get_query_var( 'ariane' );
		if($contexte == ""){
			$contexte = "Defaut";
		}
		return $contexte;
	}
	/**
	 * Adds a sub menu page to the Pods admin
	 *
	 * @param array $admin_menus The submenu items in Pods Admin menu.
	 *
	 * @return mixed
	 *
	 * @since 0.0.1
	 */
	function add_menu( $admin_menus ) {
		$admin_menus[ 'pods-genesis-maker'] = array(
			'label' => __( 'Pods Genesis Maker', 'pods-genesis-maker' ),
			'function' => array( $this, 'menu_bo' ),
			'access' => 'manage_options'

		);
		return $admin_menus;
	}

	/**
	 * This is the callback for the menu page. Be sure to create some actual functionality!
	 *
	 * @since 0.0.1
	 */
	function menu_bo() {
		$postEnCours 	= pods_v('PGM__post_type');
		$pageEnCours 	= pods_v('PGM__post_id');
		echo '<h3>Pods Genesis Maker</h3>';
		echo
			'
			<div class="pods-manage-field">
				<form method="GET">
					<input type="hidden" name="page" value="pods-genesis-maker">
					<div class="pods-field-option">
						'.$this->TabToSelect($this->TabListePostType(),'PGM__post_type',$postEnCours,'onChange=\'this.form.submit()\'').'
					</div>
				</form>
			</div>
			';
		echo $this->adminTabPods($postEnCours,$pageEnCours);
	}
	function adminTabPods($postEnCours,$pageEnCours){
		$htmlPrincipal="";
		if($postEnCours != ""){
			//test de register  hook
			$this->registerHook();
			//test de register  hook
			$this->registerContexte();
			//test de supprimer hook
			$this->supprimerHook();
			//test de supprimer contexte
			$this->supprimerContexte();
			//test de association hook
			$this->associeHook();
			//test de dissociation hook
			$this->dissocieHook();

			$htmlPrincipal 	= "";
			$contexteDefaut = "Defaut";
			$contexteTous 	= "Tous";
			global $wpdb;
			$sql="SELECT ID,post_id,contexte FROM ".$wpdb->prefix."pgm_action_post WHERE param_pods_name='".$postEnCours."' AND param_iscptslug='1'";
			$contextes = $wpdb->get_results($sql);


			//Création des onglets des contextes
			$htmlPrincipal .=
				'
				<div id="PGM_posts_Contexte">
					<ul>
						<li>
							<a href="#posts-'.$contexteTous.'">'
								.$contexteTous.'
							</a>
						</li>
						<li>
							<a href="#posts-'.$contexteDefaut.'">'
								.$contexteDefaut.'
							</a>
						</li>
				';
			
			foreach ($contextes as $contexte) {
				$tempoNiveaux = "";
				$tempoNiveauxID = "";
				foreach(explode(";", $contexte->contexte) as $niveau){
					if($niveau!="Defaut"){
						$tempoNiveaux.=get_the_title($niveau)."/";
						$tempoNiveauxID.=$niveau.";";
					}
				}
				$htmlPrincipal .=
					'
					<li>
						<a href="#posts-'.$tempoNiveauxID.$contexte->post_id.$contexte->ID.'">'
							.$tempoNiveaux.get_the_title($contexte->post_id).'
						</a>
					</li>';
			}

			//Onglet context: Tous
			$htmlPrincipal .=
				'
				<li style="position: relative;float: right;">
					<button type="button" id="PGM__closePosts" class="btn btn-info">
						<i class="glyphicon glyphicon-resize-vertical"></i>
					</button>
				</ul>
				<div id="posts-'.$contexteTous.'" class="PGM__Tabs_Posts">
					<form method="POST">
	                    <input type="hidden" name="PGM__admin_action" value="ajouter_hook">
	                	<input type="hidden" name="page" value="pods-genesis-maker">
	                	<input type="hidden" name="PGM__post_type" value="'.$postEnCours.'">
						<input type="hidden" name="PGM__post_id" value="0">
						<input type="hidden" name="PGM__contexte" value="'.$contexteTous.'">
						<table class="widefat page fixed wp-list-table" cellspacing="0">
        		';

        	$htmlPrincipal .= $this->TableEnteteAjout($contexteTous,'0',$postEnCours);
			
			$htmlPrincipal .=
				'
					</table>
				</form>
				<table class="widefat page fixed wp-list-table" cellspacing="0">
				';
			$htmlPrincipal .= $this->ListHook($contexteTous,'0',$postEnCours);	
			
			$htmlPrincipal .= 
				'
					</table>
				</div>
				';

			//Onglet context: Defaut
			$htmlPrincipal .=
				'
				<div id="posts-'.$contexteDefaut.'" class="PGM__Tabs_Posts">
					contexte : true
					<form method="POST">
	                    <input type="hidden" name="PGM__admin_action" value="ajouter_hook">
	                	<input type="hidden" name="page" value="pods-genesis-maker">
	                	<input type="hidden" name="PGM__post_type" value="'.$postEnCours.'">
						<input type="hidden" name="PGM__post_id" value="0">
						<input type="hidden" name="PGM__contexte" value="'.$contexteDefaut.'">
						<table class="widefat page fixed wp-list-table" cellspacing="0">
        		';

        	$htmlPrincipal .= $this->TableEnteteAjout($contexteDefaut,'0',$postEnCours);
			
			$htmlPrincipal .=
				'
					</table>
				</form>
				<table class="widefat page fixed wp-list-table" cellspacing="0">
				';
			
			$htmlPrincipal .= $this->ListHookAutre($contexteDefaut,'0',$postEnCours,'Tous');	

			$htmlPrincipal .= $this->ListHook($contexteDefaut,'0',$postEnCours);	
			
			$htmlPrincipal .= 
				'
					</table>
				</div>
				';

			foreach($contextes as $contexte) {
				$tempoNiveauxID = "";
				$tempoNiveaux = "";
				foreach(explode(";", $contexte->contexte) as $niveau){
					if($niveau!="Defaut"){
						$tempoNiveaux.=get_the_title($niveau)."/";
						$tempoNiveauxID.=$niveau.";";
					}
				}
				//Onglet context: Autres
				$htmlPrincipal .=
					'
					<div id="posts-'.$tempoNiveauxID.$contexte->post_id.$contexte->ID.'" class="PGM__Tabs_Posts">
						contexte : '.$tempoNiveauxID.$contexte->post_id.'
						<form method="POST">
		                    <input type="hidden" name="PGM__admin_action" value="ajouter_hook">
		                	<input type="hidden" name="page" value="pods-genesis-maker">
		                	<input type="hidden" name="PGM__post_type" value="'.$postEnCours.'">
							<input type="hidden" name="PGM__post_id" value="0">
							<input type="hidden" name="PGM__contexte" value="'.$tempoNiveauxID.$contexte->post_id.'">
							<table class="widefat page fixed wp-list-table" cellspacing="0">
	        		';

	        	$htmlPrincipal .= $this->TableEnteteAjout($tempoNiveauxID.$contexte->post_id,'0',$postEnCours);

				$htmlPrincipal .=
					'
						</table>
					</form>
					<table class="widefat page fixed wp-list-table" cellspacing="0">
					';
	        	$htmlPrincipal .= $this->ListHookAutre($tempoNiveauxID.$contexte->post_id,'0',$postEnCours,'Tous');	

				$htmlPrincipal .= $this->ListHook($tempoNiveauxID.$contexte->post_id,'0',$postEnCours);

				$htmlPrincipal .=
					'
							</table>
					</div>
					';

			}
			$htmlPrincipal .= 
				'
				</div>
				<div class="pods-manage-field">
					<form method="GET">
						<input type="hidden" name="page" value="pods-genesis-maker">
						<input type="hidden" name="PGM__post_type" value="'.$postEnCours.'">
						<div class="pods-field-option">
							'.$this->TabToSelect($this->TabListePosts($postEnCours),'PGM__post_id',$pageEnCours,'onChange=\'this.form.submit()\'').'
						</div>
					</form>
				</div>
				';
			if($pageEnCours != "" && $pageEnCours != 0){
				global $wpdb;
				$sql="SELECT ID,post_id,contexte FROM ".$wpdb->prefix."pgm_action_post WHERE param_pods_name='".$postEnCours."' AND param_iscptslug='1'";
				$contextes = $wpdb->get_results($sql);


				//Création des onglets des contextes
				$htmlPrincipal .=
					'
					<div id="PGM_tabs_Contexte">
						<ul>
							<li>
								<a href="#tabs-'.$contexteTous.'">'
									.$contexteTous.'
								</a>
							</li>
							<li>
								<a href="#tabs-'.$contexteDefaut.'">'
									.$contexteDefaut.'
								</a>
							</li>
					';
				
				foreach ($contextes as $contexte) {
					$tempoNiveaux = "";
					$tempoNiveauxID = "";
					foreach(explode(";", $contexte->contexte) as $niveau){
						if($niveau!="Defaut"){
							$tempoNiveaux.=get_the_title($niveau)."/";
							$tempoNiveauxID.=$niveau.";";
						}
					}
					$htmlPrincipal .=
						'
						<li>
							<a href="#tabs-'.$tempoNiveauxID.$contexte->post_id.$contexte->ID.'">'
								.$tempoNiveaux.get_the_title($contexte->post_id).'
							</a>
						</li>';
				}

				//Onglet context: Tous
				$htmlPrincipal .=
					'
					</ul>
					<div id="tabs-'.$contexteTous.'">
						<form method="POST">
		                    <input type="hidden" name="PGM__admin_action" value="ajouter_hook">
		                	<input type="hidden" name="page" value="pods-genesis-maker">
		                	<input type="hidden" name="PGM__post_type" value="'.$postEnCours.'">
							<input type="hidden" name="PGM__post_id" value="'.$pageEnCours.'">
							<input type="hidden" name="PGM__contexte" value="'.$contexteTous.'">
							<table class="widefat page fixed wp-list-table" cellspacing="0">
	        		';

	        	$htmlPrincipal .= $this->TableEnteteAjout($contexteTous,$pageEnCours,$postEnCours);
				
				$htmlPrincipal .=
					'
						</table>
					</form>
					<table class="widefat page fixed wp-list-table" cellspacing="0">
					';
				
				$htmlPrincipal .= $this->ListHookAutre($contexteTous,$pageEnCours,$postEnCours,$contexteTous,true);	

				$htmlPrincipal .= $this->ListHook($contexteTous,$pageEnCours,$postEnCours);	
				
				$htmlPrincipal .= 
					'
						</table>
					</div>
					';

				//Onglet context: Defaut
				$htmlPrincipal .=
					'
					<div id="tabs-'.$contexteDefaut.'">
						contexte : true
						<form method="POST">
		                    <input type="hidden" name="PGM__admin_action" value="ajouter_hook">
		                	<input type="hidden" name="page" value="pods-genesis-maker">
		                	<input type="hidden" name="PGM__post_type" value="'.$postEnCours.'">
							<input type="hidden" name="PGM__post_id" value="'.$pageEnCours.'">
							<input type="hidden" name="PGM__contexte" value="'.$contexteDefaut.'">
							<table class="widefat page fixed wp-list-table" cellspacing="0">
	        		';

	        	$htmlPrincipal .= $this->TableEnteteAjout($contexteDefaut,$pageEnCours,$postEnCours);
				
				$htmlPrincipal .=
					'
						</table>
					</form>
					<form method="POST">
	                    <input type="hidden" name="PGM__admin_action" value="ajouter_contexte">
	                	<input type="hidden" name="page" value="pods-genesis-maker">
	                	<input type="hidden" name="PGM__post_type" value="'.$postEnCours.'">
							<input type="hidden" name="PGM__post_id" value="'.$pageEnCours.'">
							<input type="hidden" name="PGM__contexte" value="'.$contexteDefaut.'">
						<table class="widefat page fixed wp-list-table" cellspacing="0">';
				$htmlPrincipal .= $this->TableEnteteAjoutContexte($contexteDefaut,$pageEnCours,$postEnCours);
				$htmlPrincipal .=
					'
							</table>
					</form>
					<table class="widefat page fixed wp-list-table" cellspacing="0">
					';

				$htmlPrincipal .= $this->ListHook($contexteDefaut,$pageEnCours,$postEnCours,true);

				$htmlPrincipal .= 
					'
					</table>
					<table class="widefat page fixed wp-list-table" cellspacing="0">
					';

				$htmlPrincipal .= $this->ListHookAutre($contexteDefaut,$pageEnCours,$postEnCours,'Tous',true);	

				$htmlPrincipal .= $this->ListHook($contexteDefaut,$pageEnCours,$postEnCours);	

				$htmlPrincipal .= 
					'
						</table>
					</div>
					';

				foreach($contextes as $contexte) {
					$tempoNiveauxID = "";
					$tempoNiveaux = "";
					foreach(explode(";", $contexte->contexte) as $niveau){
						if($niveau!="Defaut"){
							$tempoNiveaux.=get_the_title($niveau)."/";
							$tempoNiveauxID.=$niveau.";";
						}
					}
					//Onglet context: Autres
					$htmlPrincipal .=
						'
						<div id="tabs-'.$tempoNiveauxID.$contexte->post_id.$contexte->ID.'">
							contexte : '.$tempoNiveauxID.$contexte->post_id.'
							<form method="POST">
			                    <input type="hidden" name="PGM__admin_action" value="ajouter_hook">
			                	<input type="hidden" name="page" value="pods-genesis-maker">
			                	<input type="hidden" name="PGM__post_type" value="'.$postEnCours.'">
								<input type="hidden" name="PGM__post_id" value="'.$pageEnCours.'">
								<input type="hidden" name="PGM__contexte" value="'.$tempoNiveauxID.$contexte->post_id.'">
								<table class="widefat page fixed wp-list-table" cellspacing="0">
		        		';

	        		$htmlPrincipal .= $this->TableEnteteAjout($tempoNiveauxID.$contexte->post_id,$pageEnCours,$postEnCours);
				
					$htmlPrincipal .=
						'
							</table>
						</form>
						<form method="POST">
		                    <input type="hidden" name="PGM__admin_action" value="ajouter_contexte">
		                	<input type="hidden" name="page" value="pods-genesis-maker">
		                	<input type="hidden" name="PGM__post_type" value="'.$postEnCours.'">
							<input type="hidden" name="PGM__post_id" value="'.$pageEnCours.'">
							<input type="hidden" name="PGM__contexte" value="'.$tempoNiveauxID.$contexte->post_id.'">
							<table class="widefat page fixed wp-list-table" cellspacing="0">
						';
					$htmlPrincipal .= $this->TableEnteteAjoutContexte($tempoNiveauxID.$contexte->post_id,$pageEnCours,$postEnCours);
					$htmlPrincipal .=
						'
							</table>
						</form>
						<table class="widefat page fixed wp-list-table" cellspacing="0" width="100%">
						';
					$htmlPrincipal .= $this->ListHook($tempoNiveauxID.$contexte->post_id,$pageEnCours,$postEnCours,true);	

					$htmlPrincipal .=
						'
							</table>
						<table class="widefat page fixed wp-list-table" cellspacing="0">
						';
		        	$htmlPrincipal .= $this->ListHookAutre($tempoNiveauxID.$contexte->post_id,$pageEnCours,$postEnCours,'Tous',true);	

					$htmlPrincipal .= $this->ListHookAutre($tempoNiveauxID.$contexte->post_id,$pageEnCours,$postEnCours,$tempoNiveauxID.$contexte->post_id,true);

					$htmlPrincipal .= $this->ListHookAutre($tempoNiveauxID.$contexte->post_id,$pageEnCours,$postEnCours,'Tous');	

					$htmlPrincipal .= $this->ListHook($tempoNiveauxID.$contexte->post_id,$pageEnCours,$postEnCours);	

					$htmlPrincipal .=
						'
							</table>
						</div>
						';

				}
				$htmlPrincipal .= 
					'
					</div>
					';
			}
		}
		return $htmlPrincipal;
	}
	
	function associeHook(){
		//controle
		if(pods_v("PGM__admin_action",'post','')!="associe_hook"){
			return;
		}
		//config 
		$tabConfig = array(
			'pgm_action_post_id' => '%s',
			'post_id' => '%s',
			'contexte' => '%s'
			);
		$tabFields = array();
		$tabTypes = array();
		foreach ($tabConfig as $key => $value) {
			$tempo = pods_v("PGM__".$key,'post','');
			if(isset($tempo) && $tempo!=""){
				$tabFields[$key] = $tempo;
				$tabTypes[] = $value;
			}else{
				return;
			}
		}
		//ca passe => on associe
		global $wpdb;
		$wpdb->delete( 
			$wpdb->prefix."pgm_ne_pas_executer", 
			$tabFields,
			$tabTypes
		);
	}

	function dissocieHook(){
		//controle
		if(pods_v("PGM__admin_action",'post','')!="dissocie_hook"){
			return;
		}
		//config 
		$tabFields = array();
		$tabTypes = array();
		$tabConfig = array(
			'pgm_action_post_id' => '%s',
			'post_id' => '%s',
			'contexte' => '%s'
			);
		foreach ($tabConfig as $key => $value) {
			$tempo = pods_v("PGM__".$key,'post','');
			if(isset($tempo) && $tempo!=""){
				$tabFields[$key] = $tempo;
				$tabTypes[] = $value;
			}else{
				return;
			}
		}
		//ca passe => on associe
		global $wpdb;
		$wpdb->insert( 
			$wpdb->prefix."pgm_ne_pas_executer", 
			$tabFields,
			$tabTypes
		);
	}

	function supprimerHook(){
		//controle
		if(pods_v("PGM__admin_action",'post','')!="supprimer_hook" || empty(pods_v("PGM__id",'post',''))){
			return;
		}
		//ca passe => on supprime
		global $wpdb;
		$wpdb->delete( $wpdb->prefix."pgm_action_post", array( 'ID' => pods_v("PGM__id",'post','') ), array( '%d' ) );
	}
	function supprimerContexte(){
		//controle
		if(pods_v("PGM__admin_action",'post','')!="supprimer_contexte" || empty(pods_v("PGM__id",'post',''))){
			return;
		}
		//ca passe => on supprime
		global $wpdb;
		$wpdb->delete( $wpdb->prefix."pgm_action_post", array( 'ID' => pods_v("PGM__id",'post','') ), array( '%d' ) );
	}

	function registerHook(){
		//controle
		if(pods_v("PGM__admin_action",'post','')!="ajouter_hook"){
			return;
		}
		//config 
		$tabConfig = array(
			'post_type' => '%s',
			'post_id' => '%s',
			'contexte' => '%s',
			'type' => '%s',
			'hook' => '%s',
			'action' => '%s',
			'parametres' => '%s',
			'priorite' => '%s'
			);

		//controles
		$tabControle = array(
			'post_type' => true,
			'post_id' => true,
			'contexte' => true,
			'type' => true,
			'hook' => true,
			'action' => true,
			'parametres' => false,
			'priorite' => false
			);
		foreach ($tabConfig as $key => $value) {
			$tempo = pods_v("PGM__".$key,'post','');
			if(isset($tempo) && $tempo!=""){
				${"PGM__".$key} = $tempo;
			}else{
				if($tabControle[$key]){
					return;
				}
			}
		}
		//ca passe => on enregistre le nouveau hook
		global $wpdb;
		$tabFields = array();
		$tabTypes = array();
		foreach ($tabConfig as $key => $value) {
			if(isset(${"PGM__".$key})){
				$tabFields[$key] = ${"PGM__".$key};
				$tabTypes[] = $value;
			}
		}
		$wpdb->insert( 
			$wpdb->prefix."pgm_action_post", 
			$tabFields, 
			$tabTypes
		);
	}
	function registerContexte(){
		//controle
		if(pods_v("PGM__admin_action",'post','')!="ajouter_contexte"){
			return;
		}
		//config 
		$tabConfig = array(
			'post_type' => '%s',
			'post_id' => '%s',
			'contexte' => '%s',
			'param_pods_name' => '%s',
			'param_iscptslug' => '%s',
			'type' => '%s',
			);

		//controles
		$tabControle = array(
			'post_type' => true,
			'post_id' => true,
			'contexte' => true,
			'param_pods_name' => true,
			'param_iscptslug' => false,
			'type' => false
			);
		$PGM__type='ajouter_contexte';
		$PGM__param_iscptslug='1';
		foreach ($tabConfig as $key => $value) {
			$tempo = pods_v("PGM__".$key,'post','');
			if(isset($tempo) && $tempo!=""){
				${"PGM__".$key} = $tempo;
			}else{
				if($tabControle[$key]){
					return;
				}
			}
		}
		//ca passe => on enregistre le nouveau hook
		global $wpdb;
		$tabFields = array();
		$tabTypes = array();
		foreach ($tabConfig as $key => $value) {
			$tabFields[$key] = ${"PGM__".$key};
			$tabTypes[] = $value;
		}
		$tempo = $wpdb->insert( 
			$wpdb->prefix."pgm_action_post", 
			$tabFields, 
			$tabTypes
		);
		echo $tempo;
	}
	function TableEnteteAjoutContexte($contexte,$post_id,$post_type){
		return '
	                <tr class="pods-ui-col-field-name">
	                 	<td class="pods-ui-col-field-name table_PGM" style="width:20%">
	                    	Ajouter contexte
	                    </td>
	                    <td class="pods-ui-col-field-name table_PGM" style="width:70%">
	                    	'.$this->TabToSelect($this->TabListePostType(false,false),'PGM__param_pods_name').'
	                    </td>
	                    <td class="pods-ui-col-field-name table_PGM" style="width:10%">
	                    	<button type="button" class="btn btn-success buttonLoader" >
								<i class="glyphicon glyphicon-ok"></i>
							</button>
	                    </td>
	                </tr>
				';
	}
	function TableEnteteAjout($contexte,$post_id,$post_type){
		return '
				<tr>
                    <td scope="col" id="title" class="column-title" style="width:20%">
                    	<span>Type</span>
                	</td>
                	<td scope="col" id="hook" class="column-title" style="width:20%">
                    	<span>Hook</span>
                	</td>
                	<td scope="col" id="hook" class="column-title" style="width:20%">
                    	<span>Function</span>
                	</td>
                	<td scope="col" id="priorite" class="column-title" style="width:15%">
                    	<span>Priorité</span>
                	</td>
                	<td scope="col" id="nbparametres" class="column-title" style="width:15%">
                    	<span>Nb Paramètres</span>
                	</td>
                	<td scope="col" id="bouton" class="column-title" style="width:10%">
                	</td>
                </tr>
	                <tr class="pods-ui-col-field-name">
	                		
	                    <td class="pods-ui-col-field-name table_PGM" style="width:20%">
	                    	'.$this->TabToSelect($this->TabType,'PGM__type').'
	                    </td>
	                    <td class="pods-ui-col-field-name table_PGM" style="width:20%">
	                    	<input name="PGM__hook" class="pods-form-ui-field-type-text" type="text">
	                    </td>
	                    <td class="pods-ui-col-field-name table_PGM" style="width:15%">
	                    	<input name="PGM__action" class="pods-form-ui-field-type-text" type="text">
	                    </td>
	                    <td class="pods-ui-col-field-name table_PGM" style="width:15%">
	                    	<input name="PGM__priorite" class="pods-form-ui-field-type-text" type="text">
	                    </td>
	                    <td class="pods-ui-col-field-name table_PGM" style="width:15%">
	                    	<input name="PGM__parametres" class="pods-form-ui-field-type-text" type="text" maxlength="2">
	                    </td>
	                    <td class="pods-ui-col-field-name table_PGM" style="width:10%">
	                    	<button type="button" class="btn btn-success buttonLoader" >
								<i class="glyphicon glyphicon-ok"></i>
							</button>
	                    </td>
	                </tr>
				';
	}
	function ListHook($contexte,$post_id,$post_type,$config = false){
		global $wpdb;
		$html="";
		$type_hook="page";
		$label_hook = "Hooks de ".$type_hook;
		$colspan='5';
		if($post_id=="0"){
			$type_hook="post";
			$label_hook = "Hooks de ".$type_hook;
		}
		if($config=='contexte'){
			$type_hook.="contexte";
			$label_hook = "Contexte";
			$colspan='1';
		}
		$sql="SELECT * FROM ".$wpdb->prefix."pgm_action_post WHERE contexte='".$contexte."' AND post_id='".$post_id."' AND post_type='".$post_type."' AND ".$this->excludeListeHookContexte()." ORDER BY hook ASC,priorite ASC";
		$safeJsVar=str_replace(";", "_", $contexte);
		if($config=='contexte'){
			$sql="SELECT * FROM ".$wpdb->prefix."pgm_action_post WHERE contexte='".$contexte."' AND post_id='".$post_id."' AND post_type='".$post_type."' AND ".$this->excludeListeHookContexte("=")." ORDER BY hook ASC,priorite ASC";
			$safeJsVar=str_replace(";", "_", $contexte).'contexte';
		}
		$actions = $wpdb->get_results($sql);
		$html .=
				'
				<tr class="pods-ui-col-field-name">
	                <td class="table_PGM_titre table_PGM" colspan="'.$colspan.'" style="color: #31b0d5;font-size: 15px;width:90%">
	                	'.$label_hook.'
	                </td>
	                <td class="pods-ui-col-field-name table_PGM">
	                	<button type="button" class="btn btn-info showHideHookCurrent" data-showHideTypeHook="'.$type_hook.'" data-showHide="'.$safeJsVar.'">
							<i class="glyphicon glyphicon-resize-vertical"></i>
						</button>
	                </td>
	            </tr>
	           ';
		foreach ($actions as $action) {
			switch ($config) {
				case false:
					$html .=
					'
					<tr class="pods-ui-col-field-name PGM__hook_'.$type_hook.$safeJsVar.'" style="display:none;">
					'.
					$this->afficheRow([
					['20',$this->TabType[$action->type]],
					['20',$action->hook],
					['20',$action->action],
					['15',$action->priorite],
					['15',$action->parametres]
					]).'
	                    <td class="pods-ui-col-field-name table_PGM" style="width:10%">
	                    	<form method="POST">
								<input type="hidden" name="page" value="pods-genesis-maker">
								<input type="hidden" name="PGM__admin_action" value="supprimer_hook">
								<input type="hidden" name="PGM__id" value="'.$action->ID.'">
								<button type="button" class="btn btn-danger confirmMessage">
									<i class="glyphicon glyphicon-trash"></i>
								</button>
							</form>
	                    </td>
	                </tr>
					';
					break;
				case 'contexte':
					$html .=
					'
					<tr class="pods-ui-col-field-name PGM__hook_'.$type_hook.$safeJsVar.'" style="display:none;">
					'.
					$this->afficheRow([
					['90',$action->param_pods_name]
					]).'
	                    <td class="pods-ui-col-field-name table_PGM" style="width:10%">
	                    	<form method="POST">
								<input type="hidden" name="page" value="pods-genesis-maker">
								<input type="hidden" name="PGM__admin_action" value="supprimer_contexte">
								<input type="hidden" name="PGM__id" value="'.$action->ID.'">
								<button type="button" class="btn btn-danger confirmMessage">
									<i class="glyphicon glyphicon-trash"></i>
								</button>
							</form>
	                    </td>
	                </tr>
					';
					break;
			}
			
		}
		return $html;
	}
	function afficheRow($rows){
		$retour= "";
		foreach ($rows as $key => $value) {
			$retour.='<td class="pods-ui-col-field-name table_PGM" style="width:'.$value[0].'%">
                    	'.$value[1].'
                    </td>';
		}
		return $retour;
	}
	function excludeListeHookContexte($conparteur = '!='){
		if(!empty($this->excludeListeHookContexte)){
			$tempo = $this->excludeListeHookContexte;
			foreach ($tempo as $key => $value) {
				$tempo[$key] = "type  ".$conparteur.$value;
			}
			return " (".implode(" OR ", $tempo).")";
		}
		return "1=1";
	}
	function ListHookAutre($context,$post_id,$post_type,$contexteAction,$HookDePostDansPage=false,$config = false){
		global $wpdb;
		$first = true;
		$type_hook="page";
		$post_recherche = $post_id;
		$colspan='5';
		if($post_id=="0" || $HookDePostDansPage){
			$type_hook="post";
			$label_hook = "Hook de ".$type_hook;
			$post_recherche = '0';
		}
		if($config=='contexte'){
			$type_hook.="contexte";
			$label_hook = "Contexte";
			$colspan='1';
		}
		$html="";
		if($HookDePostDansPage && $contexteAction=="Tous" && $context!="Tous"){
			//Si c'est une page pas dans le contexte tous qui recherche dans le contexte tous de son post
			$sql="
			SELECT action.ID as ID, action.type as type,action.action as action,action.hook as hook, action.parametres as parametres, action.priorite as priorite, npe.pgm_action_post_id as npe, npe2.pgm_action_post_id as npe2, npe3.pgm_action_post_id as npe3
			FROM ".$wpdb->prefix."pgm_action_post action 
			LEFT JOIN `".$wpdb->prefix."pgm_ne_pas_executer` npe 
				ON npe.pgm_action_post_id = action.ID 
				AND npe.post_id='".$post_id."' 
				AND npe.contexte='".$context."' 
			LEFT JOIN `".$wpdb->prefix."pgm_ne_pas_executer` npe2
				ON npe2.pgm_action_post_id = action.ID 
				AND npe2.post_id='0'
				AND npe2.contexte='".$context."' 
			LEFT JOIN `".$wpdb->prefix."pgm_ne_pas_executer` npe3 
				ON npe3.pgm_action_post_id = action.ID 
				AND npe3.post_id='".$post_id."' 
				AND npe3.contexte='".$contexteAction."' 
			WHERE 
				action.contexte='".$contexteAction."' 
				AND action.post_id='".$post_recherche."' 
				AND action.post_type='".$post_type."' 
				AND ".$this->excludeListeHookContexte()."
			ORDER BY 
				action.hook ASC,action.priorite ASC";
			if($config=='contexte'){
				$sql="
				SELECT action.ID as ID, action.type as type,action.action as action,action.hook as hook, action.parametres as parametres, action.priorite as priorite, npe.pgm_action_post_id as npe, npe2.pgm_action_post_id as npe2, npe3.pgm_action_post_id as npe3
				FROM ".$wpdb->prefix."pgm_action_post action 
				LEFT JOIN `".$wpdb->prefix."pgm_ne_pas_executer` npe 
					ON npe.pgm_action_post_id = action.ID 
					AND npe.post_id='".$post_id."' 
					AND npe.contexte='".$context."' 
				LEFT JOIN `".$wpdb->prefix."pgm_ne_pas_executer` npe2
					ON npe2.pgm_action_post_id = action.ID 
					AND npe2.post_id='0'
					AND npe2.contexte='".$context."' 
				LEFT JOIN `".$wpdb->prefix."pgm_ne_pas_executer` npe3 
					ON npe3.pgm_action_post_id = action.ID 
					AND npe3.post_id='".$post_id."' 
					AND npe3.contexte='".$contexteAction."' 
				WHERE 
					action.contexte='".$contexteAction."' 
					AND action.post_id='".$post_recherche."' 
					AND action.post_type='".$post_type."' 
					AND ".$this->excludeListeHookContexte("=")."
				ORDER BY 
					action.hook ASC,action.priorite ASC";
			}
			$actions = $wpdb->get_results($sql);
		}else{
			//recherche des hook direct
			$sql="
			SELECT action.ID as ID, action.type as type,action.action as action,action.hook as hook, action.parametres as parametres, action.priorite as priorite, npe.pgm_action_post_id as npe 
			FROM ".$wpdb->prefix."pgm_action_post action 
			LEFT JOIN `".$wpdb->prefix."pgm_ne_pas_executer` npe 
				ON npe.pgm_action_post_id = action.ID 
				AND npe.post_id='".$post_id."' 
				AND npe.contexte='".$context."' 
			WHERE 
				action.contexte='".$contexteAction."' 
				AND action.post_id='".$post_recherche."' 
				AND action.post_type='".$post_type."' 
				AND ".$this->excludeListeHookContexte()."
			ORDER BY 
				action.hook ASC,action.priorite ASC";
			if($config=='contexte'){
				$sql="
				SELECT action.ID as ID, action.type as type,action.action as action,action.hook as hook, action.parametres as parametres, action.priorite as priorite, npe.pgm_action_post_id as npe 
				FROM ".$wpdb->prefix."pgm_action_post action 
				LEFT JOIN `".$wpdb->prefix."pgm_ne_pas_executer` npe 
					ON npe.pgm_action_post_id = action.ID 
					AND npe.post_id='".$post_id."' 
					AND npe.contexte='".$context."' 
				WHERE 
					action.contexte='".$contexteAction."' 
					AND action.post_id='".$post_recherche."' 
					AND action.post_type='".$post_type."' 
					AND ".$this->excludeListeHookContexte("=")."
				ORDER BY 
					action.hook ASC,action.priorite ASC";
			}
			$actions = $wpdb->get_results($sql);
		}
		
		foreach ($actions as $action) {
			if(empty($action->npe2) && empty($action->npe3)){
				if($action->npe !=""){
					$typeActionForm = "associe";
					$couleurButton = "success";
					$iconButton ="glyphicon-ok-circle";
					$icon = '<i class="glyphicon glyphicon-exclamation-sign"></i>';
				}else{
					$typeActionForm = "dissocie";
					$couleurButton = "danger";
					$iconButton ="glyphicon-ban-circle";
					$icon = '';
				}
				if($first){
					$safeJsVar=str_replace(";", "_", $context);
					$safeJsVar2=str_replace(";", "_", $contexteAction);
					if($config=='contexte'){
						$safeJsVar=str_replace(";", "_", $context).'contexte';
						$safeJsVar2=str_replace(";", "_", $contexteAction).'contexte';
					}
					$html .='
						<tr class="pods-ui-col-field-name">
			                <td class="table_PGM_titre table_PGM" colspan="'.$colspan.'" style="color: #31b0d5;font-size: 15px;width:90%">
			                	'.$label_hook.' - contexte "'.$contexteAction.'"
			                </td>
			                <td class="pods-ui-col-field-name table_PGM">
			                	<button type="button" class="btn btn-info showHideHook" data-showHideTypeHook="'.$type_hook.'_" data-showHide="'.$safeJsVar.'" data-contexteAction="'.$safeJsVar2.'_">
									<i class="glyphicon glyphicon-resize-vertical"></i>
								</button>
			                </td>
			            </tr>
					';
					$first = false;
				}
				$html .=
					'
					<tr class="pods-ui-col-field-name PGM__hook_'.$type_hook.'_'.$safeJsVar2.'_'.$safeJsVar.'" style="display:none;">
	                    <td class="pods-ui-col-field-name table_PGM" style="width:20%">
	                    	'.$icon.$this->TabType[$action->type].'
	                    </td>
	                    <td class="pods-ui-col-field-name table_PGM" style="width:20%">
	                    	'.$icon.$action->hook.'
	                    </td>
	                    <td class="pods-ui-col-field-name table_PGM" style="width:20%">
	                    	'.$icon.$action->action.'
	                    </td>
	                    <td class="pods-ui-col-field-name table_PGM" style="width:15%">
	                    	'.$icon.$action->priorite.'
	                    </td>
	                    <td class="pods-ui-col-field-name table_PGM" style="width:15%">
	                    	'.$icon.$action->parametres.'
	                    </td>
	                    <td class="pods-ui-col-field-name table_PGM" style="width:10%">
	                    	<form method="POST">
								<input type="hidden" name="page" value="pods-genesis-maker">
								<input type="hidden" name="PGM__admin_action" value="'.$typeActionForm.'_hook">
								<input type="hidden" name="PGM__pgm_action_post_id" value="'.$action->ID.'">
								<input type="hidden" name="PGM__post_id" value="'.$post_id.'">
								<input type="hidden" name="PGM__contexte" value="'.$context.'">
								<button type="button" class="btn btn-'.$couleurButton.' buttonLoader">
									<i class="glyphicon '.$iconButton.'"></i>
								</button>
							</form>
	                    </td>
	                </tr>
	                ';
            }
        }
        return $html;
	}

	function TabListePostType($premierElementVide = true,$includepage= true){
		//préparation liste post_types
		if($includepage){
			$inlcude = array('page','post');
		}else{
			$inlcude = array('post');
		}
		
		$exclude = array('_pods_template','_pods_pod','_pods_field');
		$tabPagePod =	array();
		if($premierElementVide){
			$tabPostsType[] = __( 'Aucune', 'pods-genesis-maker' );
		}
		foreach ($inlcude as $value) {
			$tabPostsType[$value] = $value;
		}
		foreach ( get_post_types(array('_builtin' => false)) as $post_type ) {
		   $tabPostsType[$post_type] = $post_type;
		}
		foreach ($exclude as $value) {
			unset($tabPostsType[$value]);
		}
		return $tabPostsType;
	}

	function TabListePosts($postType,$premierElementVide = true){
		//préparation liste page
		$args = array(
			'posts_per_page' => -1, 
			'hierarchical' => 1,
			'post_type' => $postType,
			'post_status' => 'publish,private,draft'
		);
		$query = new WP_Query ( $args );
		$posts = $query->posts;
		$tabPagePod =	array();
		if($premierElementVide){
			$tabPagePod[] = __( 'Aucune', 'pods-genesis-maker' );
		}
		$posts = tri_hierarchique($posts);
		foreach ($posts as $post) {
			$tempoTitlePage="";
			$level = count(get_post_ancestors($post->ID));
			for ($i=0; $i < $level; $i++) { 
				$tempoTitlePage .= "-";
			}
			$tempoTitlePage .= $post->post_title;
			$tabPagePod[$post->ID] = $tempoTitlePage;
		}
		return $tabPagePod;
	}

	function TabToSelect($tab,$name,$idSelect = '',$js=''){
		$select="<select name='$name' id='$name' $js class='pods-form-ui-field-type-pick'>";
		foreach ($tab as $key => $value) {
			$selected = "";
			if($key == $idSelect){
				$selected = " selected ";
			}
			$select.="<option value='$key' $selected >$value</option>";
		}
		$select.="</select>";
		return $select;
	}
} // Pods_Genesis_Maker

/**
 * Initialize class, if Pods is active.
 *
 * @since 0.0.1
 */
add_action( 'plugins_loaded', 'Pods_Genesis_Maker_safe_activate');
function Pods_Genesis_Maker_safe_activate() {
	if ( defined( 'PODS_VERSION' ) ) {
		$GLOBALS[ 'Pods_Genesis_Maker' ] = Pods_Genesis_Maker::init();
	}

}

/**
 * Throw admin nag if Pods isn't activated.
 *
 * Will only show on the plugins page.
 *
 * @since 0.0.1
 */
add_action( 'admin_notices', 'Pods_Genesis_Maker_admin_notice_pods_not_active' );
function Pods_Genesis_Maker_admin_notice_pods_not_active() {

	if ( ! defined( 'PODS_VERSION' ) ) {

		//use the global pagenow so we can tell if we are on plugins admin page
		global $pagenow;
		if ( $pagenow == 'plugins.php' ) {
			?>
			<div class="updated">
				<p><?php _e( 'You have activated Pods Genesis Maker, but not the core Pods plugin.', 'Pods_Genesis_Maker' ); ?></p>
			</div>
		<?php

		} //endif on the right page
	} //endif Pods is not active

}

/**
 * Throw admin nag if Pods minimum version is not met
 *
 * Will only show on the Pods admin page
 *
 * @since 0.0.1
 */
add_action( 'admin_notices', 'Pods_Genesis_Maker_admin_notice_pods_min_version_fail' );
function Pods_Genesis_Maker_admin_notice_pods_min_version_fail() {

	if ( defined( 'PODS_VERSION' ) ) {

		//set minimum supported version of Pods.
		$minimum_version = '2.3.18';

		//check if Pods version is greater than or equal to minimum supported version for this plugin
		if ( version_compare(  $minimum_version, PODS_VERSION ) >= 0) {

			//create $page variable to check if we are on pods admin page
			$page = pods_v('page','get', false, true );

			//check if we are on Pods Admin page
			if ( $page === 'pods' ) {
				?>
				<div class="updated">
					<p><?php _e( 'Pods Genesis Maker, requires Pods version '.$minimum_version.' or later. Current version of Pods is '.PODS_VERSION, 'Pods_Genesis_Maker' ); ?></p>
				</div>
			<?php

			} //endif on the right page
		} //endif version compare
	} //endif Pods is not active
}


add_action( 'genesis_init', 'PGM_genesis_breadcrumb_init', 15 );

function PGM_genesis_breadcrumb_init(){
	remove_action( 'genesis_before_loop', 'genesis_do_breadcrumbs' );
	add_action( 'genesis_before_content', 'PGM_genesis_breadcrumb',50);
}

function PGM_genesis_breadcrumb( $args = array() ) {
	include_once(plugin_dir_path( __FILE__ )."classes/ariane.php");
	global $_genesis_breadcrumb;

	if ( ! $_genesis_breadcrumb )
		$_genesis_breadcrumb = new PGM_Genesis_Breadcrumb;

	$_genesis_breadcrumb->output( $args );

}

// Add each level's child posts to the result list, in order
function recursively_flatten_list( $list, &$result ) {
	if($list != ""){
	    foreach( $list as $node ) {
	        $result[] = $node['post'];
	        if( isset( $node['children'] ) )
	            recursively_flatten_list( $node['children'], $result );
	    }
	}
}

function tri_hierarchique( $posts ) {
	foreach( $posts as $post ) {
        $thisref = &$refs[$post->ID];

        $thisref['post'] = $post;

        if( $post->post_parent == 0)
            $list[$post->ID] = &$thisref;
        else
            $refs[$post->post_parent]['children'][$post->ID] = &$thisref;
    }

    // Create single, sorted list
    $result = array();
    recursively_flatten_list( $list, $result );
    return $result;
}
register_activation_hook( __FILE__, array( 'Pods_Genesis_Maker', 'activate' ) );