<?php
class PGM_Genesis_Breadcrumb extends Genesis_Breadcrumb {
	public function __construct() {
		parent::__construct();
	}
	/**
	 * Get breadcrumb for single custom post type entry, including any parent (CPT name) crumbs.
	 *
	 * @since 2.0.0
	 *
	 * @return string HTML markup for a single custom post type entry breadcrumb, including
	 *                any parent (CPT name) breadcrumbs.
	 */ 
	protected function get_cpt_crumb() {
		global $PGM_contexte;
		$crumbs = array();
		$crumbsAncestor = array();
		$ariane = get_query_var( 'ariane' );
		$post = get_post();
		foreach ( get_post_ancestors($post) as $ancestor ) {
			array_unshift($crumbsAncestor,$this->get_breadcrumb_link(get_permalink( $ancestor ),'',get_the_title( $ancestor )));
		}
		if(!empty($ariane)){
			$PGM_contexte = "0";
			foreach (explode(";", $ariane) as $arianeItem) {
				$crumbsTempo=array();
				
			 	foreach ($this->get_ariane_crumb($arianeItem) as $value) {
				 	array_unshift($crumbsTempo,$value);
				}
				foreach ($crumbsTempo as $value) {
					$crumbs[] = $value;
				}
				if($PGM_contexte=="0"){
					$PGM_contexte = $arianeItem;
				}else{
					$PGM_contexte .= ";".$arianeItem;
				}
				
			 }

			
		}
		foreach ($crumbsAncestor as $value) {
			$crumbs[] = $value;
		}
		$crumbs[] = get_the_title( get_the_ID() );

		$crumb = join( $this->args['sep'], $crumbs );
		$PGM_contexte = "";
		return $crumb;
	}
	protected function get_ariane_crumb($ariane){
		global $PGM_contexte;
		$crumbs = array();
		$post = get_post($ariane);
		$crumbs[] = $this->get_breadcrumb_link(get_permalink( $post->ID ),'',get_the_title( $post->ID ));
		foreach ( get_post_ancestors($post) as $ancestor ) {
			$crumbs[] = $this->get_breadcrumb_link(get_permalink( $ancestor ),'',get_the_title( $ancestor ));
		}
		return $crumbs;
	}
	protected function get_post_crumb() {
		global $PGM_contexte;
		$crumbs = array();
		$ariane = get_query_var( 'ariane' );
		$post = get_post();
		if(!empty($ariane)){
			return $this->get_cpt_crumb();
		}else{
			return parent::get_post_crumb();
		}
	}
	protected function get_post_crumb_by_id($id) {

		$categories = get_the_category($id);

		if ( 1 === count( $categories ) ) {
			// If in single category, show it, and any parent categories.
			$crumb[] = $this->get_term_parents( $categories[0]->cat_ID, 'category', true );
		}
		if ( count( $categories ) > 1 ) {
			if ( ! $this->args['heirarchial_categories'] ) {
				// Don't show parent categories (unless the post happen to be explicitly in them).
				foreach ( $categories as $category ) {
					$crumbs[] = $this->get_breadcrumb_link(
						get_category_link( $category->term_id ),
						'',
						$category->name
					);
				}
			} else {
				// Show parent categories - see if one is marked as primary and try to use that.
				$primary_category_id = get_post_meta( get_the_ID(), '_category_permalink', true ); // Support for sCategory Permalink plugin.
				if ( $primary_category_id ) {
					$crumb[] = $this->get_term_parents( $primary_category_id, 'category', true );
				} else {
					$crumb[] = $this->get_term_parents( $categories[0]->cat_ID, 'category', true );
				}
			}
		}

		return $crumb;

	}
}
