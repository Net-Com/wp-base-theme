jQuery(document).ready(function($){
	$( "#PGM_tabs_Contexte" ).tabs({collapsible: true});
	$( "#PGM_posts_Contexte" ).tabs({collapsible: true});
    $( ".buttonLoader" ).click(function() {
        $(this).find($('i')).removeClass();
        $(this).find($('i')).addClass('glyphicon glyphicon-refresh gly-spin');
        $(this).closest('form').submit();
	});
	$( ".confirmMessage" ).click(function() {
        if (confirm('Êtes vous certain ?')) {
        	$(this).find($('i')).removeClass();
        	$(this).find($('i')).addClass('glyphicon glyphicon-refresh gly-spin');
        	$(this).closest('form').submit();
	    }
	});
	$( ".showHide" ).click(function() {
        $("#detail_"+$(this).attr('data-showHide')).fadeToggle();
	});
	$( ".showHideHook" ).click(function() {
        $(".PGM__hook_"+$(this).attr('data-showHideTypeHook')+$(this).attr('data-contexteAction')+$(this).attr('data-showHide')).each(function() {
			$(this).fadeToggle();
		});
	});
	$( ".showHideHookCurrent" ).click(function() {
        $(".PGM__hook_"+$(this).attr('data-showHideTypeHook')+$(this).attr('data-showHide')).each(function() {
			$(this).fadeToggle();
		});
	});
	$( "#PGM__closePosts" ).click(function() {
        $(".PGM__Tabs_Posts").each(function() {
			$(this).hide();
		});
	});
}); 