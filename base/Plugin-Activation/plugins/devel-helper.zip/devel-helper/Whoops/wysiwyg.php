<div class="meta-box-item-content">
	<?= wp_editor($value, $id); ?>
</div>