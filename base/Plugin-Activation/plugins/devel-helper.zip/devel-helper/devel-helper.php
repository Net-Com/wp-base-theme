<?php 
/*
Plugin Name: Devel-helper
Description: Module d'aide au développement.
Version: 0.1
Author: Net.Com
*/

require_once __DIR__ . '/Krumo.php'; 
?>