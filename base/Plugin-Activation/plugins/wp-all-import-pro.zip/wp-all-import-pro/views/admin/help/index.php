<h2><?php _e('WP All Import Help', 'wp_all_import_plugin') ?></h2>
	
